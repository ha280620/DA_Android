package com.example.doan_sosuckhoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class VerifyOTP extends AppCompatActivity {

    EditText edtPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);
        Intent intent = getIntent();
        String phone_number = intent.getStringExtra("phone_number");
        edtPhone = (EditText) findViewById(R.id.edtPhone);
        edtPhone.setText(phone_number);
    }
}