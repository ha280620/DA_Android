package com.example.doan_sosuckhoe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Medicalappointment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicalappointment);
    }
}